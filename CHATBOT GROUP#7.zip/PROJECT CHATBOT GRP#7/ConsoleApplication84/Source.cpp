#include<iostream>
#include<string>
#include<algorithm>
#include<fstream>
#include"chatbot.h"
using namespace std;

int main(){         
	string str1,name;
	IF l;
	chat q;
	cout<<"Hello my name is B.H.U.T.T.O.\nI am here to answer all of your questions about C++,\nSo please restrict all of your queries to C++"<<endl;
	cout<<"\n\nHow may I help you: "<<endl;
	while(true)
	{
		cout<<endl;
	getline(cin,str1);
	cout<<endl;
	transform(str1.begin(),str1.end(),str1.begin(),::tolower);
	if ((l.answer("java",str1))||(l.answer("python",str1))||(l.answer("java script",str1))||(l.answer("matlab",str1)) || (l.answer("ruby",str1)) || (l.answer("go  ",str1)))
	{
		cout<<"Sorry, i will not be able to answer this question. \nPlease restrict your queries to C++ as i was\nprogrammed to answer all of your questions related to C++."<<endl;
	continue;
	}
		if((l.answer("your",str1))&&(l.answer("name",str1)))
	{
		cout<<"You're a forgetful one. As i said before, my name is B.H.U.T.T.O. ."<<endl;
		continue;}
	if(l.answer("analytical engine",str1) || l.answer("charles babbage /a",str1))
		 q.answer(2,8,"chapter 1.txt");

	else if((l.answer("main()",str1)) || (l.answer("main function",str1)))
	{q.answer(28,30,"new.dat");
	continue;
	}
	else if(l.answer("luigi f. menabrea/a",str1))
		{q.answer(11,15,"chapter 1.txt/a"); 
	continue;
	}
	else if(l.answer("augusta ada byron/a",str1))
		{q.answer(18,23,"chapter 1.txt/a"); 
	continue;
	}
	else if(l.answer("atanasoff berry computer/a",str1) || l.answer("abc/a",str1))
		{q.answer(26,29,"chapter 1.txt");
	continue;
	}
	else if(l.answer("electronic numerical integrator and calculator/a",str1)||l.answer("eniac/a",str1))
		{q.answer(32,36,"chapter 1.txt");
	continue;
	}
	else if(l.answer("computer/a",str1))
		{q.answer(39,41,"chapter 1.txt/a");
	continue;
	}
	else if(l.answer("hardware/a",str1))
		{q.answer(44,47,"chapter 1.txt/a");
	continue;
	}
		else if(l.answer("header file",str1))
	{q.answer(61,63,"new.dat");
	continue;}
	else if(l.answer("software/a",str1))
		{q.answer(50,52,"chapter 1.txt/a");
	continue;
	}
	else if(l.answer("arithmetic logic unit/a",str1))
		{q.answer(55,57,"chapter 1.txt/a");
	continue;
	}
	else if(l.answer("cpu/a",str1) || l.answer("central processing unit/a",str1))
		{q.answer(60,61,"chapter 1.txt/a");
	continue;
	}
	else if(l.answer("machine language/a",str1))
		{q.answer(64,67,"chapter 1.txt");
	continue;
	}
	else if(l.answer("loop in loop",str1) || l.answer("nested loop",str1))
	{
	cout<<"A loop inside another loop is called a nested loop. The number of loops depend on the complexity of a problem.\nSuppose, a loop, outer loop, running n number of times consists of\n another loop inside it, inner loop, running m number of times."<<endl;
	continue;
	}
	else if(l.answer("parse error/a",str1) || l.answer("syntax error/a",str1))
		{q.answer(70,71,"chapter 1.txt/a");
	continue;
	}
	else if(l.answer("linking error/a",str1))
		{q.answer(74,75,"chapter 1.txt/a");
	continue;
	}
	else if(l.answer("run error/a",str1))
		{q.answer(78,79,"chapter 1.txt/a");
	continue;
	}
	else if(l.answer("logical error/a",str1))
		{q.answer(82,83,"chapter 1.txt/a");
	continue;
	}
	else if(l.answer("debugging/a",str1))
		{q.answer(86,89,"chapter 1.txt/a");
	continue;
	}
	else if(l.answer("problem solving methodology/a",str1))
		{q.answer(91,97,"chapter 1.txt/a");
	continue;
	}
	if(l.answer("preprocessor directives/a",str1))
		{q.answer(1,3,"chapter2.dat/a");
	continue;
	}
		else 
	if(l.answer("iostream/a",str1))
		{q.answer(5,5,"chapter2.dat/a");
	continue;
	}
		else	
	if(l.answer("cmath/a",str1))
	{	q.answer(7,7,"chapter2.dat/a");
	continue;
	}
		else	
	if(l.answer("using directive/a",str1))
	{
		q.answer(9,11,"chapter2.dat/a");
	continue;
	}
		else		
	if(l.answer("block of code/a",str1))
	
		{q.answer(13,13,"chapter2.dat/a");
	continue;
	}
		else	
	if(l.answer("declaration statement/a",str1))
	
		{q.answer(15,15,"chapter2.dat/a");
	continue;
	}
	   else   
	if(l.answer("initialization/a",str1))
		{q.answer(17,17,"chapter2.dat/a");
	continue;
	}
	   else		
	if(l.answer("variable",str1))
	
		{q.answer(19,19,"chapter2.dat");
	continue;
	}
	   else    
	if(l.answer("identifier",str1))
	
		{q.answer(21,21,"chapter2.dat");
	continue;
	}
	   else	
	if(l.answer("garbage value",str1))
	
	{	q.answer(23,23,"chapter2.dat");
	continue;
	}
	     else	
	if(l.answer("memory snapshot",str1))
	
		{q.answer(25,25,"chapter2.dat");
	continue;
	}
	     else	if(l.answer("case sensitive",str1))
	
		{q.answer(27,27,"chapter2.dat");
	continue;
	}
		   else	if(l.answer("strongly typed",str1))
	
	      {q.answer(29,29,"chapter2.dat");
		 continue;
		 }
	
		   else if(l.answer("floating point",str1))
	
		{q.answer(31,31,"chapter2.dat");
	continue;
		   }
		     else if(l.answer("scientific notation",str1))
	
		{q.answer(33,33,"chapter2.dat");
	continue;
		   }
		     else	if(l.answer("exponential notation",str1))
	
	     {q.answer(35,35,"chapter2.dat");
	 continue;
			 }
			 else	if(l.answer("precision and range",str1))
	
		{q.answer(37,37,"chapter2.dat");
	continue;
			 }
			  else	if(l.answer("type specifier",str1))
	
	        {q.answer(39,39,"chapter2.dat");
	continue;
			 }
			  else	if(l.answer("boolean data type",str1))
	
		{q.answer(41,41,"chapter2.dat");
	continue;
			  }
		 else	if(l.answer("chracters",str1))
	
		{q.answer(43,43,"chapter2.dat");
			  continue;}
			   else	if(l.answer("ansi code",str1))
	
		{q.answer(45,45,"chapter2.dat");
	continue;
		 }
		  else	if(l.answer("string data",str1))
	
		{q.answer(47,47,"chapter2.dat");
	continue;
			   }
			    else	if(l.answer("programmer defined data type",str1))
	
		{q.answer(49,49,"chapter2.dat");
	continue;
		  }
		   else	if(l.answer("class declaration",str1))
	
		{q.answer(51,51,"chapter2.dat");
	continue;
				}
				 else	if(l.answer("operators",str1))
	
		{q.answer(53,53,"chapter2.dat");
	continue;
		   }
		    else	if(l.answer("assignment statement",str1))
	
{		q.answer(55,56,"chapter2.dat");
				 continue;
				 }
				  else	if(l.answer("arithmetic",str1))
	
	{	q.answer(58,58,"chapter2.dat");
			continue;}
			 else	if(l.answer("modulus operator",str1))
	
		{q.answer(60,60,"chapter2.dat");
				  continue;}
				   else	if(l.answer("binary operator",str1))
	
		{q.answer(62,62,"chapter2.dat");
			 continue;}
			  else	if(l.answer("unary operator",str1))
	
		{q.answer(64,64,"chapter2.dat");
	
				   continue;}
		else	if(l.answer("mixed operation",str1))
	
		{q.answer(66,66,"chapter2.dat");
	
			  continue;}
			   else	if(l.answer("cast operator",str1))
	
		{q.answer(68,68,"chapter2.dat");
	continue;}
		 else	if(l.answer("underflow",str1))
	
		{q.answer(70,70,"chapter2.dat");
			   continue;}
			    else	if(l.answer("overflow",str1))
	
		{q.answer(72,72,"chapter2.dat");
		 continue;}
		  else	if(l.answer("increment operator",str1))
	
		{q.answer(74,74,"chapter2.dat");
				continue;}
				 else	if(l.answer("decrement operator ",str1))
		{q.answer(76,76,"chapter2.dat");
		  continue;}
		   else	if(l.answer("stream",str1))
	
		{q.answer(78,78,"chapter2.dat");
	
				 continue;}
				  else	if(l.answer("member function",str1))
	
		{q.answer(80,80," chapter2.dat");
		   continue;}
	    else	if(l.answer("dot operator",str1))
	
{		q.answer(82,82,"chapter2.dat");
				  continue;}	
				   else	if(l.answer("manipulator",str1))
		{q.answer(84,84,"chapter2.dat");
		continue;}
			 else	if(l.answer("cin object",str1))
	
		{q.answer(86,86,"chapter2.dat");
				   continue;}
				    else	if(l.answer("function arguement",str1))
		{q.answer(88,88,"chapter2.dat");
			 continue;}
			  else	if(l.answer("composition of function",str1))
	
{		q.answer(90,90,"chapter2.dat");
					continue;}	
					 else	if(l.answer("inverse hyperbolic function",str1))
{		q.answer(94,94,"chapter2.dat");
			  continue;}	
			   else	if(l.answer("hyperbolic function",str1))
	
		{q.answer(92,92,"chapter2.dat");
					 continue;}
			   else	if(l.answer("keyword",str1))
	
	{	q.answer(96,96,"chapter2.dat");
			   continue;}
			    else if(l.answer("comment",str1))
	
		{q.answer(98,98,"chapter2.dat");
			   continue;}
			    else	if(l.answer("field width",str1))
		{q.answer(100,100,"chapter2.dat");
				continue;}
	if(l.answer("Top down design",str1))
	{
		q.answer(1,2,"ch3.txt");
		continue;
	}
		else if(l.answer("divide and conquer strategy",str1)){
		q.answer(4,5,"ch3.txt");
		continue;
		}
		else if(l.answer("psuedo code",str1)){
		q.answer(7,11,"ch3.txt");
		continue;
		}
		else if(l.answer("flowchart",str1)){
		q.answer(13,13,"ch3.txt");
		continue;
		}
		else if(l.answer("structured programming",str1)){
		q.answer(15,16,"ch3.txt");
		continue;
		}
		else if(l.answer("sequence",str1)){
		q.answer(18,18,"ch3.txt");
		continue;
		}
		else if(l.answer("selection",str1)){
		q.answer(20,20,"ch3.txt");
		continue;
		}
		else if(l.answer("repetition",str1)){
		q.answer(22,22,"ch3.txt");
		continue;
		}
		else if(l.answer("conditions",str1)){
		q.answer(24,25,"ch3.txt");
		continue;
		}
		else if(l.answer("relational operator",str1)){
		q.answer(27,28,"ch3.txt");
		continue;
		}
		else if(l.answer("logical operator",str1)){
		q.answer(30,30,"ch3.txt");
		continue;
		}
		else if(l.answer("short circuiting",str1)){
		q.answer(32,33,"ch3.txt");
		continue;
		}
		else if(l.answer("if statement",str1)){
		q.answer(35,38,"ch3.txt");
		continue;
		}
		else if(l.answer("nested if else",str1)){
		q.answer(56,56,"ch3.txt");
		continue;
		}
	    else if(l.answer("if else statement",str1) || l.answer("if else",str1)){
		q.answer(40,45,"ch3.txt");
		continue;
		}
		else if (l.answer("switch statement",str1)){
		q.answer(47,54,"ch3.txt");
		continue;
		}
		else if(l.answer("conditional operator",str1)){
		q.answer(58,59,"ch3.txt");
		continue;
		}
		else if(l.answer("linear interpolation",str1)){
		q.answer(61,63,"ch3.txt");
		continue;
		}
		else if(l.answer("break statement",str1)){
		q.answer(65,66,"ch3.txt");
		continue;
		}
		else if(l.answer("controlling expression",str1)){
		q.answer(68,68,"ch3.txt");
		continue;
		}
		else if(l.answer("netbeans",str1)){
		q.answer(70,70,"ch3.txt");
		continue;
		}
		else if(l.answer("operator overloading",str1)){
		q.answer(72,75,"ch3.txt");
		continue;
		}
		if(l.answer("cerr",str1))
	{
		q.answer(1,2,"ch5.txt");
		}
		else if(l.answer("file stream classes",str1)){
		q.answer(4,4,"ch5.txt");
		continue;
		}
		else if(l.answer("if stream",str1) || l.answer("ifstream",str1)){
		q.answer(6,7,"ch5.txt");
		continue;
		}
		else if(l.answer("of stream",str1) || l.answer("ofstream",str1)){
		q.answer(9,10,"ch5.txt");
		continue;
		}
		else if(l.answer("multiple inheritence",str1)){
		q.answer(12,12,"ch5.txt");
		continue;
		}
		else if(l.answer("if stream object",str1) || l.answer("ifstream object",str1)){
		q.answer(14,15,"ch5.txt");
		continue;
		}
		else if(l.answer("of stream object",str1) || l.answer("ofstream object",str1)){
		q.answer(17,17,"ch5.txt");
		continue;
		}
		else if(l.answer("open function",str1) || l.answer("open()",str1)){
		q.answer(19,21,"ch5.txt");
		continue;
		}
		else if(l.answer("c_str()",str1) || l.answer("cstring",str1)){
		q.answer(23,25,"ch5.txt");
		continue;
		}
		else if(l.answer("fail function",str1) || l.answer("fail()",str1)){
		q.answer(27,28,"ch5.txt");
		continue;
		}
		else if(l.answer("sentinel signal",str1)){
		q.answer(30,30,"ch5.txt");
		continue;
		}
		else if(l.answer("end of file ",str1) || l.answer("eof",str1)){
		q.answer(32,34,"ch5.txt");
		continue;
		}
		else if(l.answer("data filters",str1)){
		q.answer(36,36,"ch5 .txt");
		continue;
		}
		else if(l.answer("error state",str1)){
		q.answer(38,40,"ch5.txt");
		continue;
		}
		else if(l.answer("state flags",str1)){
		q.answer(44,44,"ch5.txt");
		continue;
		}
	    if(l.answer("state",str1)){
		q.answer(42,42,"ch5.txt");
		continue;
		}
		else if(l.answer("good bit",str1)){
		q.answer(46,46,"ch5.txt");
		continue;
		}
		else if(l.answer("eof bit",str1)){
		q.answer(48,48,"ch5.txt");
		continue;
		}
		else if(l.answer("fail bit",str1)){
		q.answer(50,50,"ch5.txt");
		continue;
		}
		else if(l.answer("bad bit",str1)){
		q.answer(52,52,"ch5.txt");
		continue;}
		
		else if(l.answer("linear regression",str1)){
		q.answer(54,55,"ch5.txt");
		continue;
		}
		else if(l.answer("least square",str1)){
		q.answer(57,57,"ch5.txt");
		continue;
		}
		else if(l.answer("file",str1)){
			q.answer(59,63,"ch5.txt");
			continue;}
		if(l.answer("row and column offset",str1))
		q.answer(2,4,"8.txt");
			if ((l.answer("two dimensional",str1))||(l.answer("2d",str1)))
			{
	 if(l.answer("common error using ",str1))
	 {q.answer(7,9,"8.txt");continue;}
	
	else if(l.answer("syntax ",str1))
		{q.answer(12,14,"8.txt");continue;}
	
	else if(l.answer("declaration ",str1))
		{q.answer(17,19,"8.txt");continue;}
	
	else if(l.answer("initialization ",str1))
		{q.answer(22,29,"8.txt");continue;}
	
	else if(l.answer("what can be empty ",str1))
		{q.answer(32,33,"8.txt");continue;}
	
	else if(l.answer("function ",str1))
		{q.answer(36,38,"8.txt");continue;}
	
	else if(l.answer("another method to initialize ",str1))
		{q.answer(41,42,"8.txt");continue;}
	
	else if(l.answer("changing size ",str1))
		{q.answer(45,46,"8.txt");continue;}
	
	else if((l.answer("computation ",str1))||(l.answer("output",str1)))
	{	q.answer(49,50,"8.txt");continue;}
	
	else if(l.answer("functions argument ",str1))
		{q.answer(53,57,"8.txt");continue;}
	
	else if(l.answer("pre condition ",str1))
	{	q.answer(60,61,"8.txt");continue;}
	
	else if(l.answer("post condition",str1))
	{	q.answer(64,65,"8.txt");continue;}
	else
	{   cout<<"In C++ Two Dimensional array in C++ is an array that consists of more than one rows and more than one column. In 2-D array each element is refer by two indexes. Elements stored in these Arrays in the form of matrices. The first index shows a row of the matrix and the second index shows the column of the matrix."<<endl;
	continue;}
			}
	else if(l.answer("vectors class ",str1))
		q.answer(68,71,"8.txt");

	else if((l.answer("syntax ",str1))&&((l.answer("two dimensional",str1))||(l.answer("2d arrays",str1))))
		{q.answer(74,75,"8.txt");
	continue;}
	else if(l.answer("function argument of vector class",str1))
		{q.answer(78,80,"8.txt");continue;
	continue;}
	else if(l.answer("syntax of function argument",str1))
		{q.answer(83,86,"8.txt");
	continue;}
	else if(l.answer("Matrices",str1)|| l.answer("Matrix in 2d array",str1))
		{q.answer(89,96,"8.txt");
	continue;}
	else if(l.answer("difference b/w matrices in maths and c++",str1))
		{q.answer(99,101,"8.txt");
	continue;}
	else if(l.answer("determinant in c++",str1))
		{q.answer(104,110,"8.txt");
	continue;}
	else if(l.answer("addition and subtraction in matrices",str1))
		{q.answer(125,128,"8.txt");
	continue;}
	else if(l.answer("matrix multiplication",str1))
		{q.answer(131,143,"8.txt");
	continue;}
	else if(l.answer("gauss elimination",str1) || l.answer("back substitution",str1))
		{q.answer(146,160,"8.txt");
	continue;}
	else if(l.answer("ill conditioned",str1))
		{q.answer(163,165,"8.txt");
	continue;}
	else if(l.answer("pivoting",str1))
		{q.answer(168,172,"8.txt");
	continue;}
	else if(l.answer("three dimensional arrays",str1))
		{q.answer(175,178,"8.txt");
	continue;}
	else if(l.answer("four dimensional array",str1))
		{q.answer(181,183,"8.txt");
	continue;}
	else if(l.answer("five dimensional array",str1))
		{q.answer(186,188,"8.txt");
	continue;}
	else if(l.answer("Transpose of a matrix",str1))
		{q.answer(113,122,"8.txt");
	continue;}
		if(l.answer("array",str1))
	{
		 if(l.answer("advantages",str1) && l.answer("vector",str1))
	{
		q.answer(132,137,"ch7.dat");
			continue;
	}
    else if(l.answer("one dimensional",str1))
	{q.answer(8,9,"ch7.dat");
	continue;
	}
	else if(l.answer("offsets",str1))
	{q.answer(20,24,"ch7.dat");
	continue;
	}
	else if((l.answer("define",str1)) ||  (l.answer("definition",str1)))
	{
	q.answer(27,29,"ch7.dat");
	continue;
	}
	else if(l.answer("initialization",str1))
	{
		q.answer(32,34,"ch7.dat");
		continue;
	}
	else if(l.answer("size",str1))
	{
		q.answer(37,38,"ch7.dat");
		continue;
	}
	else if(l.answer("segmension error",str1))
	{
		q.answer(41,42,"ch7.dat");
			continue;
	}
	else if(l.answer("computation",str1))
	{
		q.answer(45,47,"ch7.dat");
			continue;
	}
	else if(l.answer("change max size of an array",str1) || ((l.answer("chang",str1)) && (l.answer("size",str1)) && (l.answer("max",str1) )))
	{
		q.answer(50,51,"ch7.dat");
			continue;
	}
	else if((l.answer("function ",str1)) && l.answer("arguments",str1))
	{
		q.answer(54,56,"ch7.dat");
			continue;
	}
	else if(l.answer("median",str1))
	{
		q.answer(59,62,"ch7.dat");
			continue;
	}
	
	else if(l.answer("sorting",str1))
	{
		q.answer(77,77,"ch7.dat");
			continue;
	}
	else if(l.answer("selection sort",str1))
	{
		q.answer(80,83,"ch7.dat");
			continue;
	}
	else if(l.answer("searching",str1))
	{
		q.answer(86,87,"ch7.dat");
			continue;
	}
	else
	{q.answer(2,5,"ch7.dat");}
	continue;
	}
	if(l.answer("character string",str1))
	{
		q.answer(90,92,"ch7.dat");
			continue;
	}
	if(l.answer("string function ",str1))
	{
		q.answer(95,101,"ch7.dat");
			continue;
	}
	if(l.answer("strcmp values",str1))
	{
		q.answer(104,108,"ch7.dat");
			continue;
	}
	if(l.answer("c style string",str1) || l.answer("c-style",str1))
	{
		q.answer(111,114,"ch7.dat");
			continue;
	}
	if(l.answer("varience",str1))
	{
		q.answer(65,65,"ch7.dat");
			continue;
	}
	if((l.answer("varience",str1)) && l.answer("types",str1))
	{
		q.answer(68,68,"ch7.dat");
			continue;
	}
	if(l.answer("zero crossing",str1))
	{
		q.answer(71,74,"ch7.dat");
			continue;
	}
	if(l.answer("string class",str1))
	{
		q.answer(117,117,"ch7.dat");
			continue;
	}
	if(l.answer("vector",str1))
	{
	if(l.answer("capacity",str1))
	{
		q.answer(124,129,"ch7.dat");
			continue;
	}
	else if(l.answer("parameter",str1) && l.answer("passing",str1))
	{
		q.answer(140,142,"ch7.dat");
			continue;
	}
	else if(l.answer("advantage",str1))
	{
		q.answer(132,137,"ch7.dat");
			continue;
	}
	else 
	{
		q.answer(120,121,"ch7.dat");
			continue;
	}
	if(l.answer("nondeterministic",str1) || l.answer("probabilistic",str1))
	{
		q.answer(145,147,"ch7.dat");
	}continue;
	}
	if(str1.find("flowchart")!=string::npos)
	{q.answer(12,16,"inputch4.dat");}
	
	else
		if(l.answer("psuedo code",str1))
		{q.answer(1,7,"inputch4.dat");}
		else if(l.answer("difference",str1))
							{
								if(l.answer("for loop",str1) && l.answer("while loop",str1))
								{q.answer(93,99,"inputch4.dat");
									continue;}
								if(l.answer("while loop",str1) && l.answer("do",str1))
								{
									q.answer(102,106,"inputch4.dat");
									continue;
								}
							}
			else if(l.answer("do/while loop",str1) || l.answer("do while loop",str1))
					{q.answer(47,61,"inputch4.dat");
					continue;}
				else if(l.answer("while loop",str1))
				{q.answer(26,45,"inputch4.dat");
			continue;}
				else if(l.answer("for loop",str1))
					 {q.answer(64,79,"inputch4.dat");
				continue;}
						else
						if(l.answer("repitition structures",str1))
						{q.answer(18,23,"inputch4.dat");
				continue;}
							else
								if(l.answer("break",str1))
						{	q.answer(109,114,"inputch4.dat");
				continue;}
								else
									if(l.answer("continue",str1))
									{q.answer(115,131,"inputch4.dat");
				continue;}
									else
										if(l.answer("counter controlled",str1))
											{q.answer(134,138,"inputch4.dat");
				continue;}
										else
											if(l.answer("sentinel",str1) && l.answer("value",str1))
											{	q.answer(141,147,"inputch4.dat");
				continue;}
											else
												if(l.answer("end of data",str1))
												{q.answer(150,155,"inputch4.dat");
				continue;}
													else
													if(l.answer("ide",str1) || l.answer("integrated devolpment environmnet",str1))
													{q.answer(158,161,"inputch4.dat");
				continue;}
	if(l.answer("addresses",str1))
	{q.answer(2,15,"Chap 09.txt");
	continue;}
	
	else if(l.answer("pointer",str1))
		{q.answer(18,22,"Chap 09.txt");
	continue;}
	
	else if(l.answer("base type",str1))
		{q.answer(25,27,"Chap 09.txt");
	continue;}
	
	else if(l.answer("dereferencing or indirection operator",str1))
	{q.answer(30,33,"Chap 09.txt");
	continue;}
	
	else if(l.answer("asterisk",str1))
		{q.answer(36,38,"Chap 09.txt");
	continue;}
	
	else if(l.answer("pointer arithmetic",str1))
	{q.answer(41,48,"Chap 09.txt");
	continue;}
	
	else if(l.answer("character string",str1))
	{q.answer(51,54,"Chap 09.txt");
	continue;}
	
	else if(l.answer("bad_alloc",str1))
	{		q.answer(57,62,"Chap 09.txt");
	continue;}
	
	else if(l.answer("delete operator",str1))
		{q.answer(65,67,"Chap 09.txt");
	continue;}
	
	else if(l.answer("seismic event detection",str1))
	{q.answer(70,72,"Chap 09.txt");
	continue;}
	
	else if(l.answer("linked data structures",str1))
		{q.answer(75,78,"Chap 09.txt");
	continue;}
	
	else if(l.answer("linked list",str1))
	{q.answer(81,83,"Chap 09.txt");
	continue;}
	
	else if(l.answer("stack",str1))
		{q.answer(86,90,"Chap 09.txt");
	continue;}
	
	else if(l.answer("queue",str1))
	{q.answer(93,97,"Chap 09.txt");
	continue;}
	
	else if(l.answer("deallocation",str1))
		{q.answer(100,102,"Chap 09.txt");
	continue;}
	
	else if(l.answer("indirection operator",str1))
	{q.answer(105,106,"Chap 09.txt");
	continue;}
	
	else if(l.answer("list class",str1))
		{q.answer(109,112,"Chap 09.txt");
	continue;}
	
	else if(l.answer("constant pointer",str1))
	{q.answer(115,116,"Chap 09.txt");
	continue;}
	if(l.answer("template",str1))
		{q.answer(1,4,"chap10.dat");
	continue;}
	else if (l.answer("data abstraction",str1))
		{q.answer(6,10,"chap10.dat");
	continue;}
	else if (l.answer("encapsulation",str1))
		{q.answer(12,16,"chap10.dat");
	continue;}	
	else if (l.answer("pixel",str1))
		{q.answer(19,21,"chap10.dat");
	continue;}	
	else if ((l.answer("brighten an image",str1))||((l.answer("bright",str1))&&(l.answer("image",str1))))
		{q.answer(23,25,"chap10.dat");
	continue;}
	else if ((l.answer("darken an image",str1))||((l.answer("darken",str1))&&(l.answer("image",str1))))
		{q.answer(27,28,"chap10.dat");
	continue;}		
	else if (l.answer("smoothing",str1))
		{q.answer(30,32,"chap10.dat");
	continue;}	
	else if (l.answer("bitmap",str1))
		{q.answer(34,36,"chap10.dat");
	continue;}	
	else if ((l.answer("ppm ",str1))&&(l.answer("file",str1)))
		{q.answer(38,39,"chap10.dat");
	continue;}	
	else if (l.answer("friend function",str1))
		{q.answer(41,42,"chap10.dat");
	continue;	}
	else if (l.answer("recursive function",str1))
	{	q.answer(44,46,"chap10.dat");
	continue;}	
	else if (l.answer("stack",str1))
		{q.answer(47,49,"chap10.dat");
	continue;}	
	else if (l.answer("polymorphism",str1))
		{q.answer(51,51,"chap10.dat");
	continue;}	
	else if (l.answer("dynamic binding",str1))
		{q.answer(53,54,"chap10.dat");
	continue;}	
	else if (l.answer("base class",str1))
		{q.answer(56,59,"chap10.dat");
	continue;}	
	else if (l.answer("derived class",str1))
		{q.answer(61,63,"chap10.dat");
	continue;}	
	else if (l.answer("inheritance",str1))
		{q.answer(65,68,"chap10.dat");
	continue;}	
	else if (l.answer("virtual function",str1))
		{q.answer(70,71,"chap10.dat");
	continue;}	
	else if (l.answer("generic programming",str1))
		{q.answer(73,75,"chap10.dat");
	continue;}	
	else if (l.answer("iterated prisoner's dilemma",str1))
		{q.answer(77,79,"chap10.dat");
	continue;}
	if(l.answer("modularity",str1))
		{q.answer(16,20,"inputch6.dat");
	continue;}							
	else	if(l.answer("abstraction",str1))
	{q.answer(23,29,"inputch6.dat");
	continue;}
	else if(l.answer("library function",str1))
		{q.answer(32,33,"inputch6.dat");
	continue;}
	else
	if(l.answer("programmer defined function",str1))
	{q.answer(36,37,"inputch6.dat");
	continue;}
		else if((l.answer("class",str1)) && (l.answer("function",str1)))
	{q.answer(68,69,"new.dat");
	continue;}
	else if(l.answer("types",str1) && l.answer("function",str1))
		{q.answer(40,42,"inputch6.dat");
		continue;
		}
	else 
		if(l.answer("types of user defined function",str1))
		{q.answer(45,47,"inputch6.dat");
	continue;}
	else if(l.answer("function prototype",str1))
		{q.answer(57,68,"inputch6.dat");
	continue;}
	else 
	if(l.answer("function definition",str1))
	{q.answer(80,99,"inputch6.dat");
	continue;}
	else
 if(l.answer("function header",str1))
	 {q.answer(103,112,"inputch6.dat");
	continue;}
 else
  if(l.answer("function argument",str1))
  {q.answer(115,129,"inputch6.dat");
	continue;}
  else if(l.answer("function overloading",str1 ))
  {
	  q.answer(56,58,"new.dat");
  continue;}
  
  else
  if(l.answer("pass by value",str1) || l.answer("passed by value",str1))
  {q.answer(132,157,"inputch6.dat");
  continue;}
  else
  if(l.answer("pass by reference",str1) || l.answer("passed by reference",str1))
  {q.answer(160,211,"inputch6.dat");
  continue;}
  else
  if(l.answer("formal parameter",str1))
	 { q.answer(71,77,"inputch6.dat");
  continue;}
  else																				
 if(l.answer("static",str1) && l.answer("storage class",str1))
 {q.answer(230,235,"inputch6.dat");
  continue;}
  else
  if(l.answer("external",str1) && l.answer("storage class",str1))									
	  {q.answer(245,246,"inputch6.dat");
  continue;}
  else
  if(l.answer("automatic",str1) && l.answer("storage class",str1))
  {q.answer(250,251,"inputch6.dat");
  continue;}
  else
  if(l.answer("storage class",str1))
	  {q.answer(220,227,"inputch6.dat");
  continue;}
  else
  if(l.answer("global scope",str1) || l.answer("local scope",str1))																		
	  {q.answer(261,263,"inputch6.dat");
  continue;}
  else
 if(l.answer("scope",str1))
 {q.answer(254,258,"inputch6.dat");
  continue;}
 else
  if((l.answer("random number",str1))||(l.answer("rand ",str1))||(l.answer("rand function",str1)))
	  {q.answer(266,278,"inputch6.dat");
  continue;}
  else
  if(l.answer("seed",str1))
  { q.answer(281,289,"inputch6.dat");
  continue;}
	if(str1.find("syntax error")!=string::npos)
		{q.answer(1,7,"errors.dat");
	continue;}
	else if(l.answer("semantic error",str1))
	{q.answer(10,21,"errors.dat");
	continue;}
	else
	if(l.answer("runtime error",str1))
	{q.answer(27,31,"errors.dat");
	continue;}
	else
	if(l.answer("logical error",str1))
		{q.answer(35,41,"errors.dat");
	continue;}
	else
	if(l.answer("linking error",str1))
	{q.answer(44,48,"errors.dat");
	continue;}
	else if(l.answer("class",str1))
	{q.answer(1,6,"new.dat");
	continue;}
	else if(l.answer("operator",str1))
	{q.answer(17,25,"new.dat");
	continue;}
	else if (l.answer("loop",str1))
	{q.answer(33,37,"new.dat");
	continue;}
    else if(l.answer("inheritance",str1))
	{q.answer(40,42,"new.dat");
	continue;}
	else if(l.answer("polymorphism",str1))
	{q.answer(45,48,"new.dat");
	continue;}
	else if((l.answer("programing",str1)) || (l.answer("coding",str1)))
	{q.answer(51,53,"new.dat");
	continue;}

	else if(l.answer("void",str1))
	{q.answer(72,73,"new.dat");
	continue;}
	else if(l.answer("int",str1))
	{q.answer(76,77,"new.dat");
	continue;}
	else if(l.answer("double",str1))
	{q.answer(80,81,"new.dat");
	continue;}
	else if(l.answer("float",str1))
	{q.answer(83,83,"new.dat");
	continue;}
	
	else
  if(l.answer("function",str1) || l.answer("module",str1))
	 { q.answer(8,13,"inputch6.dat");
  continue;}
	else if(l.answer("c++",str1))
	{q.answer(9,14,"new.dat");
	continue;}
	else if( l.answer("bye",str1) || l.answer("end",str1) || l.answer("goodbye",str1))
	{
		cout<<"It was nice talking to you. I hope we will meet again.\nAllah Hafiz and happy coding."<<endl;
		exit(1);
	}
	else
		{cout<<"Sorry, I did not understand what you were trying to say,\nIf your question was about C++ and I could not answer it,\nPlease refer the following website www.cplusplus.com"<<endl;
     }
}

system("pause");
return 0;
}