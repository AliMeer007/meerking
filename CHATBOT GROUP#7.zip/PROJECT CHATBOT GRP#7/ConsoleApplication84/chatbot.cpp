#include "chatbot.h"
#include<iostream>
#include<string>
#include<fstream>
using namespace std;
void chat::answer(int a,int x,string file){
	string str3;
	ifstream fin(file);
	if (fin.fail())
	{
		cerr<<"fail to open the file"<<endl;
	}
	else 
		{string paragraph;
	for(int n=0;n<=x;n++){
getline(fin,str3);
if (n>=a)
{
 paragraph += str3 + "\n";
}
    }
       cout<<paragraph<<endl;
	}   
}
int IF:: answer(string str2,string str1)
{
	if((str1.find(str2)!=string::npos))
	{return 1;}
	else{return 0;}
}