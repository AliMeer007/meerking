#pragma once
#include<string>
using namespace std;
class chat
{ 
public:
	string str1;
	void answer(int a,int x,string file);
};
class IF:public chat 
{
	public:   
	int answer(string str2,string str1);
};